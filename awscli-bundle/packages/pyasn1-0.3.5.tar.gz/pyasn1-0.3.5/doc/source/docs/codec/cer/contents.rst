
Canonical Encoding Rules
------------------------

.. autofunction:: pyasn1.codec.cer.encoder.encode(value)

.. autofunction:: pyasn1.codec.cer.decoder.decode(substrate, asn1Spec=None)
